# Take in an integer greater than 1. Print out the cubes of each integer from 0 to the inputted integer.

number = int(input("Please enter a number: "))
print("The number you entered is: ")
print(number)